use fource;
DROP TABLE IF EXISTS Inventory;
CREATE TABLE Inventory (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    quantity_in_stock INT,
    unit_price DECIMAL(8, 2),
    item_number BIGINT,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO Inventory (product_id, product_name, item_number, quantity_in_stock, unit_price)
VALUES (101,'Widget A',7835839852,50,12.99),
       (102,'Widget B',7248735897,30,8.49),
       (103,'Widget C',7498237598,75,19.99),
       (104,'Widget D',4832583758,60,14.99);
select * from Inventory;