use fource;
DROP TABLE IF EXISTS UserData;
CREATE TABLE UserData (
    user_id INT DEFAULT 0, -- INT with default value
    account_balance BIGINT DEFAULT 1000000000, -- BIGINT with default value
    is_active TINYINT DEFAULT 1, -- TINYINT (1 byte) with default value (0 or 1 for boolean)
    average_score FLOAT DEFAULT 0.0, -- FLOAT with default value
    discount DECIMAL(5,2) DEFAULT 0.00, -- DECIMAL with default value (5 total digits, 2 after decimal)
    registration_date DATE DEFAULT '2023-01-01', -- DATE with default value
    last_login_time TIME DEFAULT '00:00:00' -- TIME with default value
);
INSERT INTO UserData (user_id, average_score) VALUES (1, 85.5); 
select * from UserData;