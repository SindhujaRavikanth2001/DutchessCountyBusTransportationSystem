use fource;
DROP TABLE IF EXISTS User;
CREATE TABLE User (
    user_id INT PRIMARY KEY,
    username VARCHAR(20) DEFAULT 'guest', -- VARCHAR default value
    first_name CHAR(10) DEFAULT 'John', -- CHAR default value
    last_name CHAR(10) DEFAULT 'Doe', -- CHAR default value
    status ENUM('Active', 'Inactive') DEFAULT 'Active', -- ENUM default value
    permissions SET('Read', 'Write', 'Execute') DEFAULT 'Read' -- SET default value
);
INSERT INTO User (user_id, username, permissions) VALUES (1, 'user1', 'Read,Write');
select * from User;