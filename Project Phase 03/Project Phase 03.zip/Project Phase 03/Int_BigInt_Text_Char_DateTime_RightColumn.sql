use fource;
DROP TABLE IF EXISTS UserActivityLog;
CREATE TABLE UserActivityLog (
    log_id BIGINT PRIMARY KEY,
    user_id INT,
    name CHAR(20),
    activity_details TEXT,
    activity_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO UserActivityLog (log_id, user_id, name, activity_details)
VALUES (2347847, 101, 'Sindhu', 'Logged in successfully.'),
       (3498273, 102, 'Gaurav','Uploaded a new profile picture.'),
       (3273829, 101, 'Shannu','Posted a status update.'),
       (4873812, 103, 'Chanakya','Liked a post.');
select * from UserActivityLog;